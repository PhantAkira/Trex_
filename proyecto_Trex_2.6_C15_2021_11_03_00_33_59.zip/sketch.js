var PLAY = 1;
var END = 0;
var gameState = PLAY;
var colision,gameOver,gameOver2,restarto; 

var jumpSound,dieSound,scoreSound;
var trex, trex_running, trex_collided;
var ground, invisibleGround, groundImage, groupObstacles;
var clouds,obstacle, cloudGroup;
var nube,rand,randow,score = 0;
var message;

function preload(){
  trex_running = loadAnimation("trex2.png","trex3.png","trex1.png");
  trex_collided = loadImage("trex_collided.png");
  
  nube = loadImage("cloud.png");
  
  groundImage = loadImage("ground2.png");
  
  obstacle1Img = loadImage("obstacle1.png");
  obstacle2Img = loadImage("obstacle2.png");
  obstacle3Img = loadImage("obstacle3.png");
  obstacle4Img = loadImage("obstacle4.png");
  obstacle5Img = loadImage("obstacle5.png");
  obstacle6Img = loadImage("obstacle6.png");
  
  gameOverr = loadImage("gameOver.png");
  restartoIMG= loadImage("restart.png");
  //cargar sonidos
  
  jumpSound = loadSound("jump.mp3");
  dieSound = loadSound("die.mp3");
  scoreSound = loadSound("checkPoint.mp3");
}


function setup() {

  createCanvas(600,200)
  
  //crea el sprite del Trex
  trex = createSprite(50,160,20,50);
  trex.addAnimation("running", trex_running);
   trex.addAnimation
   ("IColision",trex_collided);
  trex.scale = 0.5;
  trex.setCollider("circle",0,0,50);
  trex.debug= false;
  
  //crea el sprite del suelo
  ground = createSprite(200,180,400,20);
  ground.addImage("ground",groundImage);
  ground.x = ground.width /2;

  gameOver = createSprite(300,100);
  gameOver.addImage("gameover",gameOverr);
  gameOver.scale = 0.5;
  gameOver.visible = false;
  
  restarto = createSprite(300,130);
  restarto.addImage("restarto",restartoIMG);
  restarto.scale = 0.3;
  restarto.visible = false;
  
  //crea el suelo invisible
  invisibleGround = createSprite(200,190,400,10);
  invisibleGround.visible = false;
 //random = Math.round(random(1,100));
  
  groupObstacle = new Group();
  cloudGroup = new Group();
  
  
}

function draw() {
  //establece el color del fondo
  background(150);
  
  //mostrar score
  fill ("blue");
  textSize (20);
  text (score,20,20);
 
  console.log(gameState);
  

  //numero random
  if(gameState === PLAY){
    //aumentar score
    score = score + Math.round(getFrameRate() / 60 );
    // sonido de checkPoint
    if (score > 0 && score % 100 === 0 ){
      scoreSound.play();
        }
    //salta cuando se presiona la barra espaciadora
    if(keyDown ("space")&& trex.y >= 160) {
       trex.velocityY = -15;
       }
  if(keyWentDown ("space")&& trex.y >= 160) {
       jumpSound.play();
       }
    
    
   // dar gravedad al Trex
      trex.velocityY = trex.velocityY + 0.8;  
    
  // hacer el piso infinito
   if (ground.x < 0){
       ground.x = ground.width/2;
         }
   //función que me muestre las nubes
      spawClouds();
      spawnCactus();
  //velocidad al piso
      ground.velocityX = -(4 + score / 100);
    
  //si el trex toca los obstaculos cambia el         //estado de juego
  
    if (groupObstacle.isTouching(trex)){
      gameState = END;
      dieSound.play();
       }
  }else if(gameState === END){
      //detiene el piso
     ground.velocityX = 0;
     groupObstacle.setVelocityXEach(0);
     cloudGroup.setVelocityXEach(0);
     groupObstacle.setLifetimeEach(-11);
     cloudGroup.setLifetimeEach(-6);

      // cambiar imagen al trex
     trex.changeAnimation ("IColision",trex_collided);

     //dejar congelado al trex
      trex.velocityX= 0;
      trex.velocityY= 0;

      //mostrar sprite de game over y restart
      restarto.visible = true;
      gameOver.visible = true;
    
  }
 

  
  //evita que el Trex caiga
  trex.collide(invisibleGround);
  
  //si clickean el boton de reinicio se reinicia
  if(mousePressedOver(restarto) && gameState === END){
      reiniciar();
       }
  
  drawSprites();

}

function spawClouds(){
  

   if (frameCount %60 === 0){
    clouds = createSprite (600,20,30,20);   
    clouds.addImage(nube);
    //clouds.scale = 0.8;
     
    
    clouds.scale =  Math.random(0.8,0.7);
    clouds.y = Math.round(random(10,150));
    clouds.velocityX = -6; 
     
     //ajustar profundidad del trex con respecto
     //a las nubes
     clouds.depth = trex.depth;
     trex.depth = clouds.depth +1;
     
     // tiempo de vida de nubes
     
     clouds.lifetime = 215;
     
     cloudGroup.add(clouds);
     
    //console.log(trex.depth);
    console.log(clouds.scale);
       }
  
  
}

function spawnCactus () {
  if (frameCount %60 === 0){
   obstacle = createSprite (600,170,20,40);
   obstacle.velocityX = -(5 + score / 100);

    
   //genera obstaculos al azar
   randow = Math.round(random(1,6));
  switch(randow) {
    case 1: obstacle.addImage(obstacle1Img); 
            break;
    case 2: obstacle.addImage(obstacle2Img); 
            break;
    case 3: obstacle.addImage(obstacle3Img); 
            break;
    case 4: obstacle.addImage(obstacle4Img); 
            break;
    case 5: obstacle.addImage(obstacle5Img); 
            break;
    case 6 : obstacle.addImage(obstacle6Img); 
            break;
    default : break;
     }
    
   //Ciclo de vida y escala 
    obstacle.scale = 0.59;
    obstacle.lifetime = 160;
    //agregar obstaculos al grupo
    groupObstacle.add(obstacle);
    }
   
}

function reiniciar(){
    gameState = PLAY;
    restarto.visible = false;
    gameOver.visible = false;
    groupObstacle.destroyEach();
    cloudGroup.destroyEach();
    trex.changeAnimation ("running", trex_running);
    score = 0;
  
}
